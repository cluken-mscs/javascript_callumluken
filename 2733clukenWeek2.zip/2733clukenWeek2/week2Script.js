

            let v1 = "Callum Luken";
            let v2 = 9;
            const v3 = .5;

            let sum = v2 + v3;


            firstName = "Callum";
            lastName = "Luken";

            const c = 3;

            x = 5;
            z = 7;

            document.getElementById("inputField").value = firstName;
            


